package ro.cts.clase;

public interface PacientAbstract {
    void afiseazaPacient(Spitalizare spitalizare);
}
