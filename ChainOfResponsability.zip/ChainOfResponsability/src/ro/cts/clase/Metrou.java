package ro.cts.clase;

public class Metrou extends InfoMijloc{
    @Override
    public void recomandaMijloc(int distanta) {
        System.out.println("Calatorul va lua metroul");
    }
}