package ro.cts.clase;

public interface IRezervare {
    void rezerva(String numeClient, int nrPersoane, int ora);
}
