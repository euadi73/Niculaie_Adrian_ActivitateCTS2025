package ro.cts.clase;

public interface Observer {
    void primesteMesaj(String mesaj);
}