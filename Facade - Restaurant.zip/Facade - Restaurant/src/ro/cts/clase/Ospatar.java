package ro.cts.clase;

public class Ospatar {

    public boolean esteAranjata(Masa masa) {
        return masa.getNrMasa() % 5 == 0;
    }

}
