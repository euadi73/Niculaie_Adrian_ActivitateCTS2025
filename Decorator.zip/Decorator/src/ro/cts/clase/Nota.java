package ro.cts.clase;

public interface Nota {
    void printare();
}
